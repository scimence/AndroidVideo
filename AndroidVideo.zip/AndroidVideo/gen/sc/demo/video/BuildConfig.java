/** Automatically generated file. DO NOT MODIFY */
package sc.demo.video;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}