
package com.sc.tool;

import java.io.File;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.widget.MediaController;
import android.widget.Toast;
import android.widget.VideoView;


/** AndroidManifest.xml中配置：
 * 
<uses-permission android:name="android.permission.INTERNET" />
<uses-permission android:name="android.permission.READ_EXTERNAL_STORAGE" />

<activity android:name="com.sc.tool.ShowFile" 
	android:theme="@android:style/Theme.NoTitleBar.Fullscreen" >
	<intent-filter>
	    <action android:name="intent.action.ShowVideo" />
	    <category android:name="android.intent.category.DEFAULT" />
	</intent-filter>
</activity>

*/

/** 展示指定的视屏调用： ShowVideo.Open() */
public class ShowVideo extends Activity
{
	/** 使用当前Activity打开，指定路径下的视屏文件,
	 * videoPath：可以为本地文件路径、或视屏文件网址 */
	public static void Open(Context context, String videoPath)
	{
		if(videoPath.equals("")) return;
		Toast.makeText(context, "播放视屏文件：" + videoPath, Toast.LENGTH_SHORT).show();
		Toast.makeText(context, "待加载完成后，点击播放", Toast.LENGTH_SHORT).show();
		
		Intent intent = new Intent();
		intent.setAction("intent.action.ShowVideo");
		intent.putExtra("VideoPath", videoPath);
		// intent.setPackage(context.getPackageName());	// 用当前应用中的ShowFile打开
		
		context.startActivity(intent);
	}
	
//	/** 使用当前Activity打开，指定路径下的视屏文件,
//	 * data:文件对应的Uri */
//	public static void Open(Context context, Uri data)
//	{
//		Intent intent = new Intent();
//		intent.setAction("intent.action.ShowVideo");
//		intent.putExtra("VideoPath", "USE_URI_DATA");
//		
//		intent.setData(data);
//		// intent.setPackage(context.getPackageName());	// 用当前应用中的ShowFile打开
//		
//		context.startActivity(intent);
//	}
	
	@Override
	protected void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
		
		// 获取指定的视屏文件并显示
		Intent intent = this.getIntent();
		String videoPath = intent.getStringExtra("VideoPath");
		
		// 从网址或文件路径生成Uri
		Uri uri = null;
		/*if(videoPath.equals("USE_URI_DATA"))
		{
			uri = intent.getData();
		}
		else*/
		{
			if(videoPath.startsWith("http://") || videoPath.startsWith("https://"))
			{	// "http://scimence.gitee.io/androidvideo/1.mp4";
				uri = Uri.parse(videoPath);
			}
			else
			{	// "/sdcard/sc/video/tank_zmpy.mp4";
				uri=Uri.fromFile(new File(videoPath));
			}
		}
		
		// 创建视屏播放View
		VideoView videoView = new VideoView(this);
		{
			videoView.setVideoURI(uri);		
			
			MediaController cotrol = new MediaController(this);		// 视屏播放控制器
			
			videoView.setMediaController(cotrol);
			cotrol.setMediaPlayer(videoView);
		}
		
		this.setContentView(videoView);
		
		// 播放下一个、前一个
		//		OnClickListener next = new OnClickListener()
		//		{
		//			@Override
		//			public void onClick(View v)
		//			{
		//				// TODO Auto-generated method stub
		//				
		//			}
		//		};
		//		
		//		cotrol.setPrevNextListeners(next, null);
		
	}
	
}
