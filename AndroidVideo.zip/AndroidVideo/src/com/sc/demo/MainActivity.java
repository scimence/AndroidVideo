
package com.sc.demo;

import sc.demo.video.R;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.sc.tool.ShowVideo;


public class MainActivity extends Activity
{
	EditText edit;
	
	@Override
	protected void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
		
		this.setContentView(R.layout.activity_main);
		edit = (EditText) this.findViewById(R.id.textWebUrl);
	}
	
	/** 选择播放本地视屏资源 */
	public void btnLocal_Click(View view)
	{
		Toast.makeText(this, "请选取一个待播放的视屏文件", Toast.LENGTH_SHORT).show();
		selectFile(this, "video/*", true);	// 选取视屏并播放
		
//		ShowVideo.Open(this, "/sdcard/sc/video/tank_zmpy.mp4");	// 播放指定路径下的视屏
	}
	
	/** 播放网址对应的视屏资源 */
	public void btnWeb_Click(View view)
	{
		String videoPath = edit.getText().toString();
		ShowVideo.Open(this, videoPath);
	}
	
	/** 调用系统方法选择文件 */
	private void selectFile(Activity context, String type, boolean autoPlay)
	{
		Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
		intent.setType(type);								// 设置类型，我这里是任意类型，任意后缀的可以这样写。
		intent.addCategory(Intent.CATEGORY_OPENABLE);
		
		if (autoPlay)
			context.startActivityForResult(intent, SELECT);
		else context.startActivityForResult(intent, SELECT_ONLY);
	}
	
	final static int SELECT_ONLY = 3;	// 标记选取
	final static int SELECT = 1;	// 标记选取
	final static int SHARE = 2;		// 标记分享
	
	/** Activity执行结果 */
	protected void onActivityResult(int requestCode, int resultCode, Intent data)
	{
		if (resultCode == Activity.RESULT_OK)
		{
			if (requestCode == SELECT)
			{
				Uri uri = data.getData();
//				ShowVideo.Open(this, uri);	// 打开选取的视屏
				
				String filePath = getPath(this, uri);
				ShowVideo.Open(this, filePath);	// 打开选取的视屏
			}
		}
	}
	
	/** 获取Uri对应的文件路径 */
	public static String getPath(Context context, Uri uri)
	{
		try
		{
			if ("content".equalsIgnoreCase(uri.getScheme()))
			{
				String[] projection = { "_data" };
				Cursor cursor = null;
				try
				{
					cursor = context.getContentResolver().query(uri, projection, null, null, null);
					int column_index = cursor.getColumnIndexOrThrow("_data");
					if (cursor.moveToFirst()) 
					{ 
						return cursor.getString(column_index); 
					}
				}
				catch (Exception e)
				{
				}
			}
			else if ("file".equalsIgnoreCase(uri.getScheme())) { return uri.getPath(); }
			return null;
		}
		catch(Exception ex)
		{
			return "";
		}
	}
}
